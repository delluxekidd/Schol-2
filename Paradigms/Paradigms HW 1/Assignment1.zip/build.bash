#!/bin/bash
set -u -e
echo ""
echo "Building..."
javac Assignment1.java
echo "Built successfully, executing..."
echo ""
java Assignment1
